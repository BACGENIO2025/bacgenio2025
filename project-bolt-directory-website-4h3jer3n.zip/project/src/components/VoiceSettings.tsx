import React, { useState, useEffect } from 'react';
import { 
  Volume2, 
  VolumeX, 
  Settings, 
  Play, 
  Pause,
  RotateCcw,
  Mic,
  Speaker,
  Sliders,
  TestTube
} from 'lucide-react';

interface VoiceSettings {
  voice: SpeechSynthesisVoice | null;
  rate: number;
  volume: number;
  pitch: number;
}

interface VoiceSettingsProps {
  isEnabled: boolean;
  onToggle: () => void;
  currentSettings: VoiceSettings;
  onVoiceChange: (voice: SpeechSynthesisVoice | null) => void;
  onRateChange: (rate: number) => void;
  onVolumeChange: (volume: number) => void;
  onPitchChange?: (pitch: number) => void;
}

export const VoiceSettings: React.FC<VoiceSettingsProps> = ({
  isEnabled,
  onToggle,
  currentSettings,
  onVoiceChange,
  onRateChange,
  onVolumeChange,
  onPitchChange
}) => {
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [isTestPlaying, setIsTestPlaying] = useState(false);

  useEffect(() => {
    const loadVoices = () => {
      const voices = speechSynthesis.getVoices();
      setAvailableVoices(voices);
    };

    loadVoices();
    speechSynthesis.addEventListener('voiceschanged', loadVoices);

    return () => {
      speechSynthesis.removeEventListener('voiceschanged', loadVoices);
    };
  }, []);

  const testVoice = () => {
    if (isTestPlaying) {
      speechSynthesis.cancel();
      setIsTestPlaying(false);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(
      'Teste de voz do sistema BAC BO ML Analyzer. Nova predição: Player com 85% de confiança.'
    );
    
    if (currentSettings.voice) {
      utterance.voice = currentSettings.voice;
    }
    utterance.rate = currentSettings.rate;
    utterance.volume = currentSettings.volume;
    utterance.pitch = currentSettings.pitch || 1;

    utterance.onstart = () => setIsTestPlaying(true);
    utterance.onend = () => setIsTestPlaying(false);
    utterance.onerror = () => setIsTestPlaying(false);

    speechSynthesis.speak(utterance);
  };

  const resetToDefaults = () => {
    onVoiceChange(null);
    onRateChange(1);
    onVolumeChange(1);
    if (onPitchChange) onPitchChange(1);
  };

  const getVoiceLanguage = (voice: SpeechSynthesisVoice) => {
    if (voice.lang.includes('pt')) return '🇧🇷 Português';
    if (voice.lang.includes('en')) return '🇺🇸 English';
    if (voice.lang.includes('es')) return '🇪🇸 Español';
    return voice.lang;
  };

  const getVoiceGender = (voice: SpeechSynthesisVoice) => {
    const name = voice.name.toLowerCase();
    if (name.includes('female') || name.includes('woman') || name.includes('feminino')) return '♀️';
    if (name.includes('male') || name.includes('man') || name.includes('masculino')) return '♂️';
    return '🎭';
  };

  return (
    <div className="bg-slate-900/50 backdrop-blur-xl rounded-3xl p-8 border border-purple-500/30 shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg">
              {isEnabled ? (
                <Volume2 className="w-6 h-6 text-white" />
              ) : (
                <VolumeX className="w-6 h-6 text-white" />
              )}
            </div>
            {isEnabled && (
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-600 animate-ping opacity-30" />
            )}
          </div>
          <div>
            <h3 className="text-white font-black text-2xl bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              NOTIFICAÇÕES VOZ
            </h3>
            <p className="text-purple-300">
              Sistema de áudio • Predições em tempo real
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={resetToDefaults}
            className="p-3 bg-slate-700/50 hover:bg-slate-600/50 text-slate-400 hover:text-white rounded-xl transition-all border border-slate-600/30"
            title="Restaurar padrões"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
          
          <button
            onClick={onToggle}
            className={`
              px-6 py-3 rounded-xl font-bold transition-all duration-300 shadow-lg
              ${isEnabled 
                ? 'bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-green-500/25' 
                : 'bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white shadow-red-500/25'
              }
              hover:scale-105 transform
            `}
          >
            {isEnabled ? 'ATIVADO' : 'DESATIVADO'}
          </button>
        </div>
      </div>

      {/* Status Card */}
      <div className={`
        p-6 rounded-2xl mb-8 border transition-all duration-300
        ${isEnabled 
          ? 'bg-green-500/10 border-green-500/30' 
          : 'bg-red-500/10 border-red-500/30'
        }
      `}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-3 h-3 rounded-full ${isEnabled ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} />
            <span className="text-white font-bold text-lg">
              {isEnabled ? '🔊 Sistema Ativo' : '🔇 Sistema Inativo'}
            </span>
          </div>
          <div className="text-right">
            <p className="text-white/60 text-sm">Última notificação</p>
            <p className="text-white font-mono text-sm">
              {isEnabled ? new Date().toLocaleTimeString() : '--:--:--'}
            </p>
          </div>
        </div>
      </div>

      {/* Voice Selection */}
      <div className="grid lg:grid-cols-2 gap-8 mb-8">
        <div className="bg-slate-800/30 rounded-2xl p-6 border border-slate-700/30">
          <div className="flex items-center gap-3 mb-6">
            <Mic className="w-5 h-5 text-purple-400" />
            <h4 className="text-white font-bold text-lg">Seleção de Voz</h4>
          </div>

          <div className="space-y-3">
            <div className="p-3 bg-slate-700/30 rounded-lg border border-slate-600/30">
              <div className="flex items-center justify-between mb-2">
                <span className="text-slate-300 text-sm">Voz Atual:</span>
                <span className="text-purple-400 font-bold text-sm">
                  {currentSettings.voice ? getVoiceGender(currentSettings.voice) : '🤖'}
                </span>
              </div>
              <p className="text-white font-semibold">
                {currentSettings.voice ? currentSettings.voice.name : 'Voz Padrão do Sistema'}
              </p>
              {currentSettings.voice && (
                <p className="text-slate-400 text-xs mt-1">
                  {getVoiceLanguage(currentSettings.voice)}
                </p>
              )}
            </div>

            <select
              value={currentSettings.voice?.name || ''}
              onChange={(e) => {
                const selectedVoice = availableVoices.find(v => v.name === e.target.value) || null;
                onVoiceChange(selectedVoice);
              }}
              className="w-full bg-slate-700/50 text-white rounded-lg px-4 py-3 border border-slate-600/30 focus:border-purple-400 focus:outline-none"
            >
              <option value="">Voz Padrão do Sistema</option>
              {availableVoices
                .filter(voice => voice.lang.includes('pt') || voice.lang.includes('en'))
                .map((voice, index) => (
                  <option key={index} value={voice.name}>
                    {getVoiceGender(voice)} {voice.name} - {getVoiceLanguage(voice)}
                  </option>
                ))}
            </select>
          </div>
        </div>

        {/* Audio Controls */}
        <div className="bg-slate-800/30 rounded-2xl p-6 border border-slate-700/30">
          <div className="flex items-center gap-3 mb-6">
            <Sliders className="w-5 h-5 text-cyan-400" />
            <h4 className="text-white font-bold text-lg">Controles de Áudio</h4>
          </div>

          <div className="space-y-6">
            {/* Volume */}
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-300">🔊 Volume</span>
                <span className="text-cyan-400 font-bold">{Math.round(currentSettings.volume * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={currentSettings.volume}
                onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer slider"
              />
            </div>

            {/* Rate */}
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-slate-300">⚡ Velocidade</span>
                <span className="text-yellow-400 font-bold">{currentSettings.rate.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="2"
                step="0.1"
                value={currentSettings.rate}
                onChange={(e) => onRateChange(parseFloat(e.target.value))}
                className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer slider"
              />
            </div>

            {/* Pitch */}
            {onPitchChange && (
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-slate-300">🎵 Tom</span>
                  <span className="text-pink-400 font-bold">{(currentSettings.pitch || 1).toFixed(1)}</span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={currentSettings.pitch || 1}
                  onChange={(e) => onPitchChange(parseFloat(e.target.value))}
                  className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer slider"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Test Controls */}
      <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-2xl p-6 border border-purple-500/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <TestTube className="w-5 h-5 text-purple-400" />
            <div>
              <h4 className="text-white font-bold">Teste de Voz</h4>
              <p className="text-purple-300 text-sm">Ouça como ficará a notificação</p>
            </div>
          </div>

          <button
            onClick={testVoice}
            disabled={!isEnabled}
            className={`
              flex items-center gap-3 px-6 py-3 rounded-xl font-bold transition-all duration-300 shadow-lg
              ${isEnabled
                ? isTestPlaying
                  ? 'bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white shadow-red-500/25'
                  : 'bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white shadow-purple-500/25'
                : 'bg-slate-700/50 text-slate-500 cursor-not-allowed'
              }
              hover:scale-105 transform
            `}
          >
            {isTestPlaying ? (
              <>
                <Pause className="w-5 h-5" />
                <span>PARAR TESTE</span>
              </>
            ) : (
              <>
                <Play className="w-5 h-5" />
                <span>TESTAR VOZ</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Usage Tips */}
      <div className="mt-8 p-6 bg-slate-800/20 rounded-2xl border border-slate-700/20">
        <div className="flex items-center gap-3 mb-4">
          <Settings className="w-5 h-5 text-slate-400" />
          <h5 className="text-white font-bold">💡 Dicas de Uso</h5>
        </div>
        <div className="grid md:grid-cols-2 gap-4 text-sm text-slate-300">
          <div>
            <p className="mb-2">• <span className="text-cyan-400">Volume:</span> Ajuste conforme ambiente</p>
            <p className="mb-2">• <span className="text-yellow-400">Velocidade:</span> 1.0x é o padrão ideal</p>
          </div>
          <div>
            <p className="mb-2">• <span className="text-purple-400">Voz:</span> Escolha português para melhor pronúncia</p>
            <p className="mb-2">• <span className="text-green-400">Teste:</span> Sempre teste antes de usar</p>
          </div>
        </div>
      </div>

      <style jsx>{`
        .slider::-webkit-slider-thumb {
          appearance: none;
          height: 20px;
          width: 20px;
          border-radius: 50%;
          background: linear-gradient(45deg, #8b5cf6, #ec4899);
          cursor: pointer;
          box-shadow: 0 0 10px rgba(139, 92, 246, 0.5);
        }

        .slider::-moz-range-thumb {
          height: 20px;
          width: 20px;
          border-radius: 50%;
          background: linear-gradient(45deg, #8b5cf6, #ec4899);
          cursor: pointer;
          border: none;
          box-shadow: 0 0 10px rgba(139, 92, 246, 0.5);
        }
      `}</style>
    </div>
  );
};