import React, { useState, useEffect } from 'react';
import { FolderRoot as Football, TrendingUp, Target, Clock, Users, BarChart3, Zap, AlertTriangle, ExternalLink } from 'lucide-react';

interface Match {
  id: string;
  homeTeam: string;
  awayTeam: string;
  time: number;
  score: string;
  appm: number;
  cg: number;
  rm: number;
  bo: number;
  league: string;
  status: 'live' | 'upcoming' | 'finished';
}

interface Strategy {
  id: string;
  name: string;
  description: string;
  condition: string;
  icon: string;
  color: string;
  active: boolean;
}

interface FootballSectionProps {
  onNotification: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const FootballSection: React.FC<FootballSectionProps> = ({ onNotification }) => {
  const [matches, setMatches] = useState<Match[]>([]);
  const [strategies, setStrategies] = useState<Strategy[]>([
    {
      id: 'funil-10min',
      name: 'Funil de Escanteios 10min',
      description: 'Entrada entre 0\' a 10\'',
      condition: 'BO ≥ 6 + jogo importante',
      icon: '⚡',
      color: 'from-yellow-500 to-orange-600',
      active: true
    },
    {
      id: 'cantos-limite',
      name: 'Cantos No Limite',
      description: 'Intervalo: 70\' até fim do jogo',
      condition: 'APPM ≥ 1 + CG ≥ 15',
      icon: '🎯',
      color: 'from-red-500 to-pink-600',
      active: true
    },
    {
      id: 'over-ht',
      name: 'Over HT (1º Tempo)',
      description: 'Entrada entre 30\' a 45\' do 1T',
      condition: 'APPM ≥ 1.3 + CG ≥ 10 + BO ≥ 6 + RM ≥ 100',
      icon: '🔥',
      color: 'from-green-500 to-emerald-600',
      active: true
    },
    {
      id: 'ambos-marcam',
      name: 'Ambos Marcam (BTTS)',
      description: 'Até 70\' de jogo',
      condition: 'CG ≥ 20 + tempo < 70',
      icon: '⚽',
      color: 'from-blue-500 to-cyan-600',
      active: true
    },
    {
      id: 'zoiao',
      name: 'Estratégia Zóião',
      description: 'Após 80\' de jogo',
      condition: 'APPM ≥ 1 + CG ≥ 15 + empate/favorito perdendo',
      icon: '👁️',
      color: 'from-purple-500 to-violet-600',
      active: true
    }
  ]);

  // Simular dados de jogos ao vivo
  useEffect(() => {
    const generateMatches = () => {
      const teams = [
        ['Real Madrid', 'Barcelona'],
        ['Manchester City', 'Liverpool'],
        ['PSG', 'Marseille'],
        ['Bayern Munich', 'Dortmund'],
        ['Juventus', 'Inter Milan'],
        ['Flamengo', 'Palmeiras'],
        ['Corinthians', 'São Paulo'],
        ['Arsenal', 'Chelsea'],
        ['Atletico Madrid', 'Valencia'],
        ['AC Milan', 'Napoli']
      ];

      const leagues = [
        'La Liga', 'Premier League', 'Ligue 1', 'Bundesliga', 
        'Serie A', 'Brasileirão', 'Champions League', 'Copa do Brasil'
      ];

      return teams.slice(0, 8).map((team, index) => ({
        id: `match-${index}`,
        homeTeam: team[0],
        awayTeam: team[1],
        time: Math.floor(Math.random() * 90) + 1,
        score: `${Math.floor(Math.random() * 3)}-${Math.floor(Math.random() * 3)}`,
        appm: Math.random() * 2 + 0.5,
        cg: Math.floor(Math.random() * 30) + 5,
        rm: Math.floor(Math.random() * 200) + 50,
        bo: Math.floor(Math.random() * 10) + 3,
        league: leagues[Math.floor(Math.random() * leagues.length)],
        status: 'live' as const
      }));
    };

    setMatches(generateMatches());

    // Atualizar dados a cada 30 segundos
    const interval = setInterval(() => {
      setMatches(prev => prev.map(match => ({
        ...match,
        time: Math.min(90, match.time + Math.floor(Math.random() * 3)),
        appm: Math.max(0, match.appm + (Math.random() - 0.5) * 0.2),
        cg: match.cg + Math.floor(Math.random() * 2),
        rm: match.rm + Math.floor(Math.random() * 10) - 5
      })));
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  // Verificar estratégias
  useEffect(() => {
    matches.forEach(match => {
      strategies.forEach(strategy => {
        if (!strategy.active) return;

        let shouldAlert = false;
        let alertMessage = '';

        switch (strategy.id) {
          case 'funil-10min':
            if (match.time <= 10 && match.bo >= 6) {
              shouldAlert = true;
              alertMessage = `🚨 [FUNIL 10MIN] ${match.homeTeam} x ${match.awayTeam} - Entrada válida para escanteio!`;
            }
            break;

          case 'cantos-limite':
            if (match.time >= 70 && match.appm >= 1 && match.cg >= 15) {
              shouldAlert = true;
              alertMessage = `🚨 [CANTOS NO LIMITE] ${match.homeTeam} x ${match.awayTeam} - Entrada validada!`;
            }
            break;

          case 'over-ht':
            if (match.time >= 30 && match.time <= 45 && match.appm >= 1.3 && match.cg >= 10 && match.bo >= 6 && match.rm >= 100) {
              shouldAlert = true;
              alertMessage = `🚨 [OVER HT] ${match.homeTeam} x ${match.awayTeam} - Entrada possível para gol no 1º tempo!`;
            }
            break;

          case 'ambos-marcam':
            if (match.time < 70 && match.cg >= 20) {
              shouldAlert = true;
              alertMessage = `🚨 [AMBOS MARCAM] ${match.homeTeam} x ${match.awayTeam} - Alta produção ofensiva!`;
            }
            break;

          case 'zoiao':
            if (match.time >= 80 && match.appm >= 1 && match.cg >= 15) {
              shouldAlert = true;
              alertMessage = `🚨 [ZÓIÃO] ${match.homeTeam} x ${match.awayTeam} - Reta final intensa!`;
            }
            break;
        }

        if (shouldAlert) {
          onNotification(alertMessage, 'info');
        }
      });
    });
  }, [matches, strategies, onNotification]);

  const toggleStrategy = (strategyId: string) => {
    setStrategies(prev => prev.map(s => 
      s.id === strategyId ? { ...s, active: !s.active } : s
    ));
  };

  return (
    <div className="bg-slate-900/50 backdrop-blur-xl rounded-3xl p-8 border border-green-500/20 shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg">
            <Football className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-white font-black text-2xl bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
              FUTEBOL ANALYZER
            </h3>
            <p className="text-green-300">
              Estratégias automáticas • Alertas em tempo real
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-4 py-2 bg-green-500/20 rounded-xl border border-green-500/30">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <span className="text-green-400 font-bold text-sm">AO VIVO</span>
            </div>
          </div>
        </div>
      </div>

      {/* Strategies Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {strategies.map(strategy => (
          <div
            key={strategy.id}
            className={`
              relative p-4 rounded-xl border transition-all cursor-pointer
              ${strategy.active 
                ? 'bg-gradient-to-br ' + strategy.color + ' border-white/20 shadow-lg' 
                : 'bg-slate-800/30 border-slate-700/30 hover:border-slate-600/50'
              }
            `}
            onClick={() => toggleStrategy(strategy.id)}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xl">{strategy.icon}</span>
              <div className={`w-3 h-3 rounded-full ${strategy.active ? 'bg-white' : 'bg-slate-500'}`} />
            </div>
            <h4 className={`font-bold text-sm mb-1 ${strategy.active ? 'text-white' : 'text-slate-300'}`}>
              {strategy.name}
            </h4>
            <p className={`text-xs mb-2 ${strategy.active ? 'text-white/80' : 'text-slate-400'}`}>
              {strategy.description}
            </p>
            <p className={`text-xs ${strategy.active ? 'text-white/60' : 'text-slate-500'}`}>
              {strategy.condition}
            </p>
          </div>
        ))}
      </div>

      {/* Live Matches */}
      <div className="mb-6">
        <h4 className="text-white font-bold text-lg mb-4 flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-green-400" />
          Jogos ao Vivo ({matches.length})
        </h4>
        
        <div className="grid gap-4">
          {matches.map(match => (
            <div key={match.id} className="bg-slate-800/30 rounded-xl p-4 border border-slate-700/30">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="text-white font-bold">
                    {match.homeTeam} vs {match.awayTeam}
                  </div>
                  <div className="px-2 py-1 bg-green-500/20 rounded text-green-400 text-xs font-bold">
                    {match.league}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-white font-bold">{match.score}</div>
                  <div className="flex items-center gap-1 text-green-400">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm font-bold">{match.time}'</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-4 gap-4">
                <div className="text-center">
                  <p className="text-slate-400 text-xs">APPM</p>
                  <p className="text-white font-bold">{match.appm.toFixed(1)}</p>
                </div>
                <div className="text-center">
                  <p className="text-slate-400 text-xs">CG</p>
                  <p className="text-white font-bold">{match.cg}</p>
                </div>
                <div className="text-center">
                  <p className="text-slate-400 text-xs">RM</p>
                  <p className="text-white font-bold">{match.rm}</p>
                </div>
                <div className="text-center">
                  <p className="text-slate-400 text-xs">BO</p>
                  <p className="text-white font-bold">{match.bo}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-green-500/20 rounded-xl p-4 text-center border border-green-500/30">
          <p className="text-green-400 text-sm mb-1">Estratégias Ativas</p>
          <p className="text-green-400 text-2xl font-bold">
            {strategies.filter(s => s.active).length}
          </p>
        </div>

        <div className="bg-blue-500/20 rounded-xl p-4 text-center border border-blue-500/30">
          <p className="text-blue-400 text-sm mb-1">Jogos Monitorados</p>
          <p className="text-blue-400 text-2xl font-bold">{matches.length}</p>
        </div>

        <div className="bg-yellow-500/20 rounded-xl p-4 text-center border border-yellow-500/30">
          <p className="text-yellow-400 text-sm mb-1">Alertas Hoje</p>
          <p className="text-yellow-400 text-2xl font-bold">12</p>
        </div>

        <div className="bg-purple-500/20 rounded-xl p-4 text-center border border-purple-500/30">
          <p className="text-purple-400 text-sm mb-1">Taxa de Acerto</p>
          <p className="text-purple-400 text-2xl font-bold">84%</p>
        </div>
      </div>
    </div>
  );
};