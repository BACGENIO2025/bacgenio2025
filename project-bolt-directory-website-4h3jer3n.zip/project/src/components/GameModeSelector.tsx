import React from 'react';
import { Shield, Zap, Flame, Target, TrendingUp, AlertTriangle } from 'lucide-react';

interface GameMode {
  id: 'normal' | 'medium' | 'advanced';
  name: string;
  description: string;
  riskLevel: string;
  bankPercentage: string;
  accuracy: string;
  icon: React.ReactNode;
  gradient: string;
  borderColor: string;
  glowColor: string;
}

interface GameModeSelectorProps {
  selectedMode: 'normal' | 'medium' | 'advanced';
  onModeChange: (mode: 'normal' | 'medium' | 'advanced') => void;
}

export const GameModeSelector: React.FC<GameModeSelectorProps> = ({ selectedMode, onModeChange }) => {
  const gameModes: GameMode[] = [
    {
      id: 'normal',
      name: 'CONSERVADOR',
      description: 'Baixo risco, alta segurança',
      riskLevel: 'Baixo',
      bankPercentage: '3%',
      accuracy: '65-75%',
      icon: <Shield className="w-8 h-8" />,
      gradient: 'from-emerald-400 to-teal-600',
      borderColor: 'border-emerald-500/50',
      glowColor: 'shadow-emerald-500/20'
    },
    {
      id: 'medium',
      name: 'EQUILIBRADO',
      description: 'Risco moderado, boa rentabilidade',
      riskLevel: 'Médio',
      bankPercentage: '5%',
      accuracy: '70-80%',
      icon: <Zap className="w-8 h-8" />,
      gradient: 'from-yellow-400 to-orange-600',
      borderColor: 'border-yellow-500/50',
      glowColor: 'shadow-yellow-500/20'
    },
    {
      id: 'advanced',
      name: 'AGRESSIVO',
      description: 'Alto risco, máxima rentabilidade',
      riskLevel: 'Alto',
      bankPercentage: '8%',
      accuracy: '75-85%',
      icon: <Flame className="w-8 h-8" />,
      gradient: 'from-red-400 to-pink-600',
      borderColor: 'border-red-500/50',
      glowColor: 'shadow-red-500/20'
    }
  ];

  return (
    <div className="bg-slate-900/30 backdrop-blur-xl rounded-3xl p-8 border border-slate-700/50 shadow-2xl">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-black text-white mb-3">
          MODO DE OPERAÇÃO
        </h2>
        <p className="text-slate-400 text-lg">
          Selecione sua estratégia de <span className="text-cyan-400 font-semibold">risco</span> e <span className="text-pink-400 font-semibold">rentabilidade</span>
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {gameModes.map((mode) => {
          const isSelected = selectedMode === mode.id;
          
          return (
            <button
              key={mode.id}
              onClick={() => onModeChange(mode.id)}
              className={`
                relative group p-6 rounded-2xl transition-all duration-500 transform hover:scale-105
                ${isSelected 
                  ? `bg-gradient-to-br ${mode.gradient} shadow-2xl ${mode.glowColor} scale-105` 
                  : 'bg-slate-800/50 hover:bg-slate-800/80 border border-slate-700/50 hover:border-slate-600'
                }
              `}
            >
              {/* Glow Effect for Selected */}
              {isSelected && (
                <div className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${mode.gradient} blur-xl opacity-30 -z-10`} />
              )}

              <div className="text-center space-y-4">
                {/* Icon */}
                <div className={`
                  w-16 h-16 mx-auto rounded-2xl flex items-center justify-center mb-4
                  ${isSelected 
                    ? 'bg-white/20 text-white' 
                    : 'bg-slate-700/50 text-slate-400 group-hover:text-white group-hover:bg-slate-700'
                  }
                `}>
                  {mode.icon}
                </div>

                {/* Mode Name */}
                <h3 className={`
                  text-xl font-black tracking-wider
                  ${isSelected ? 'text-white' : 'text-slate-300 group-hover:text-white'}
                `}>
                  {mode.name}
                </h3>

                {/* Description */}
                <p className={`
                  text-sm leading-relaxed
                  ${isSelected ? 'text-white/90' : 'text-slate-400 group-hover:text-slate-300'}
                `}>
                  {mode.description}
                </p>

                {/* Stats */}
                <div className="space-y-3 pt-4 border-t border-white/10">
                  <div className="flex items-center justify-between">
                    <span className={`text-xs ${isSelected ? 'text-white/80' : 'text-slate-500'}`}>
                      Risco:
                    </span>
                    <div className="flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      <span className={`text-xs font-bold ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                        {mode.riskLevel}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className={`text-xs ${isSelected ? 'text-white/80' : 'text-slate-500'}`}>
                      Banca:
                    </span>
                    <div className="flex items-center gap-1">
                      <Target className="w-3 h-3" />
                      <span className={`text-xs font-bold ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                        {mode.bankPercentage}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className={`text-xs ${isSelected ? 'text-white/80' : 'text-slate-500'}`}>
                      Precisão:
                    </span>
                    <div className="flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" />
                      <span className={`text-xs font-bold ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                        {mode.accuracy}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Selection Indicator */}
                {isSelected && (
                  <div className="absolute top-4 right-4">
                    <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                      <div className="w-2 h-2 bg-current rounded-full" />
                    </div>
                  </div>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Mode Info */}
      <div className="mt-8 p-6 bg-slate-800/30 rounded-2xl border border-slate-700/30">
        <div className="flex items-center justify-center gap-4">
          <div className="text-center">
            <p className="text-slate-400 text-sm mb-1">Modo Selecionado</p>
            <p className="text-white font-bold text-lg capitalize">{selectedMode}</p>
          </div>
          <div className="w-px h-12 bg-slate-600" />
          <div className="text-center">
            <p className="text-slate-400 text-sm mb-1">Status da IA</p>
            <p className="text-cyan-400 font-bold text-lg">Pronta</p>
          </div>
          <div className="w-px h-12 bg-slate-600" />
          <div className="text-center">
            <p className="text-slate-400 text-sm mb-1">Próxima Análise</p>
            <p className="text-pink-400 font-bold text-lg">30s</p>
          </div>
        </div>
      </div>
    </div>
  );
};