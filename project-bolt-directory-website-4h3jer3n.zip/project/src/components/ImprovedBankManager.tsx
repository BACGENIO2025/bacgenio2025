import React, { useState, useEffect } from 'react';
import { BankManagement } from '../types';
import { 
  Wallet, 
  TrendingUp, 
  TrendingDown, 
  Target, 
  Edit3, 
  Save, 
  X, 
  RotateCcw, 
  AlertTriangle, 
  Settings, 
  BarChart3, 
  DollarSign, 
  Plus, 
  Minus, 
  Play, 
  Pause, 
  Zap, 
  Calendar, 
  Award,
  ArrowUp,
  ArrowDown
} from 'lucide-react';

interface ImprovedBankManagerProps {
  bankData: BankManagement;
  updateBank: (field: keyof BankManagement, value: number) => void;
  resetBank: () => void;
  setPresetValues: (preset: 'conservative' | 'moderate' | 'aggressive') => void;
  getProgress: () => number;
  getStatusColor: () => string;
  getRiskLevel: () => { level: string; color: string };
  onAutoEntryToggle?: (enabled: boolean) => void;
  autoEntryEnabled?: boolean;
  onDeposit: (amount: number) => void;
  onWithdraw: (amount: number) => void;
}

interface BankStatistics {
  totalProfit: number;
  totalLoss: number;
  netProfit: number;
  totalEntries: number;
  winRate: number;
  avgWin: number;
  avgLoss: number;
  maxWin: number;
  maxLoss: number;
  profitFactor: number;
}

interface EntryRecord {
  id: string;
  timestamp: Date;
  type: 'GREEN' | 'RED' | 'DEPOSIT' | 'WITHDRAW';
  amount: number;
  balance: number;
  galeLevel?: number;
}

interface DailySession {
  date: string;
  initialBank: number;
  finalBank: number;
  profit: number;
  profitPercentage: number;
  totalEntries: number;
  greens: number;
  reds: number;
  winRate: number;
}

export const ImprovedBankManager: React.FC<ImprovedBankManagerProps> = ({
  bankData,
  updateBank,
  resetBank,
  setPresetValues,
  getProgress,
  getStatusColor,
  getRiskLevel,
  onAutoEntryToggle,
  autoEntryEnabled = false,
  onDeposit,
  onWithdraw
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editValues, setEditValues] = useState(bankData);
  const [showPresets, setShowPresets] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [entryRecords, setEntryRecords] = useState<EntryRecord[]>([]);
  const [totalGreens, setTotalGreens] = useState(0);
  const [totalReds, setTotalReds] = useState(0);
  const [totalApostado, setTotalApostado] = useState(0);
  const [sessionStartBank, setSessionStartBank] = useState(bankData.initialBank);
  const [dailySessions, setDailySessions] = useState<DailySession[]>([]);
  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');

  // Carregar dados salvos
  useEffect(() => {
    const savedRecords = localStorage.getItem('genio-entry-records');
    const savedGreens = localStorage.getItem('genio-total-greens');
    const savedReds = localStorage.getItem('genio-total-reds');
    const savedApostado = localStorage.getItem('genio-total-apostado');
    const savedSessionStart = localStorage.getItem('genio-session-start-bank');
    const savedDailySessions = localStorage.getItem('genio-daily-sessions');

    if (savedRecords) {
      try {
        const records = JSON.parse(savedRecords);
        setEntryRecords(records.map((r: any) => ({ ...r, timestamp: new Date(r.timestamp) })));
      } catch (error) {
        console.error('Erro ao carregar registros:', error);
      }
    }

    if (savedGreens) setTotalGreens(parseInt(savedGreens));
    if (savedReds) setTotalReds(parseInt(savedReds));
    if (savedApostado) setTotalApostado(parseFloat(savedApostado));
    if (savedSessionStart) setSessionStartBank(parseFloat(savedSessionStart));
    if (savedDailySessions) {
      try {
        setDailySessions(JSON.parse(savedDailySessions));
      } catch (error) {
        console.error('Erro ao carregar sessões diárias:', error);
      }
    }
  }, []);

  // Salvar dados quando mudarem
  useEffect(() => {
    localStorage.setItem('genio-entry-records', JSON.stringify(entryRecords));
    localStorage.setItem('genio-total-greens', totalGreens.toString());
    localStorage.setItem('genio-total-reds', totalReds.toString());
    localStorage.setItem('genio-total-apostado', totalApostado.toString());
    localStorage.setItem('genio-session-start-bank', sessionStartBank.toString());
    localStorage.setItem('genio-daily-sessions', JSON.stringify(dailySessions));
  }, [entryRecords, totalGreens, totalReds, totalApostado, sessionStartBank, dailySessions]);

  const handleDeposit = () => {
    const amount = parseFloat(depositAmount);
    if (amount > 0) {
      onDeposit(amount);
      
      const record: EntryRecord = {
        id: `deposit_${Date.now()}`,
        timestamp: new Date(),
        type: 'DEPOSIT',
        amount: amount,
        balance: bankData.currentBank + amount
      };
      
      setEntryRecords(prev => [record, ...prev.slice(0, 99)]);
      setDepositAmount('');
    }
  };

  const handleWithdraw = () => {
    const amount = parseFloat(withdrawAmount);
    if (amount > 0 && amount <= bankData.currentBank) {
      onWithdraw(amount);
      
      const record: EntryRecord = {
        id: `withdraw_${Date.now()}`,
        timestamp: new Date(),
        type: 'WITHDRAW',
        amount: -amount,
        balance: bankData.currentBank - amount
      };
      
      setEntryRecords(prev => [record, ...prev.slice(0, 99)]);
      setWithdrawAmount('');
    }
  };

  const addEntry = (type: 'GREEN' | 'RED', galeLevel: number = 0) => {
    let multiplier = 1;
    if (galeLevel === 1) multiplier = 2;
    if (galeLevel === 2) multiplier = 4;

    const entryAmount = bankData.entryValue * multiplier;
    let newBalance = bankData.currentBank;

    if (type === 'GREEN') {
      const profit = entryAmount * (galeLevel === 0 ? 1 : galeLevel === 1 ? 1 : 3);
      newBalance += profit;
      setTotalGreens(prev => prev + 1);
    } else {
      newBalance = Math.max(0, newBalance - entryAmount);
      setTotalReds(prev => prev + 1);
    }

    setTotalApostado(prev => prev + entryAmount);
    updateBank('currentBank', newBalance);

    const record: EntryRecord = {
      id: `entry_${Date.now()}`,
      timestamp: new Date(),
      type,
      amount: type === 'GREEN' ? entryAmount : -entryAmount,
      balance: newBalance,
      galeLevel
    };

    setEntryRecords(prev => [record, ...prev.slice(0, 99)]);
  };

  const calculateStatistics = (): BankStatistics => {
    const greens = entryRecords.filter(r => r.type === 'GREEN');
    const reds = entryRecords.filter(r => r.type === 'RED');

    const totalProfit = greens.reduce((sum, r) => sum + Math.abs(r.amount), 0);
    const totalLoss = reds.reduce((sum, r) => sum + Math.abs(r.amount), 0);
    const netProfit = totalProfit - totalLoss;
    const totalEntries = greens.length + reds.length;
    const winRate = totalEntries > 0 ? (greens.length / totalEntries) * 100 : 0;

    const avgWin = greens.length > 0 ? totalProfit / greens.length : 0;
    const avgLoss = reds.length > 0 ? totalLoss / reds.length : 0;
    const maxWin = greens.length > 0 ? Math.max(...greens.map(r => Math.abs(r.amount))) : 0;
    const maxLoss = reds.length > 0 ? Math.max(...reds.map(r => Math.abs(r.amount))) : 0;
    const profitFactor = totalLoss > 0 ? totalProfit / totalLoss : totalProfit > 0 ? 999 : 0;

    return {
      totalProfit,
      totalLoss,
      netProfit,
      totalEntries,
      winRate,
      avgWin,
      avgLoss,
      maxWin,
      maxLoss,
      profitFactor
    };
  };

  const handleSave = () => {
    Object.keys(editValues).forEach(key => {
      updateBank(key as keyof BankManagement, editValues[key as keyof BankManagement]);
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditValues(bankData);
    setIsEditing(false);
  };

  const handleReset = () => {
    if (confirm('Tem certeza que deseja zerar todos os dados da gestão de banca?')) {
      resetBank();
      setTotalGreens(0);
      setTotalReds(0);
      setTotalApostado(0);
      setEntryRecords([]);
      setDailySessions([]);
      setSessionStartBank(0);
      setEditValues({
        initialBank: 0,
        currentBank: 0,
        target: 0,
        stopLoss: 0,
        stopWin: 0,
        entryValue: 0
      });
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const profit = bankData.currentBank - sessionStartBank;
  const profitPercentage = sessionStartBank > 0 ? ((profit / sessionStartBank) * 100) : 0;
  const riskLevel = getRiskLevel();
  const statistics = calculateStatistics();

  return (
    <div className="bg-slate-900/50 backdrop-blur-xl rounded-3xl p-8 border border-cyan-500/20 shadow-2xl">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-2xl">
            <Wallet className="w-8 h-8 text-white" />
          </div>
          <div>
            <h3 className="text-3xl font-black bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
              GESTÃO DE BANCA PRO
            </h3>
            <p className="text-slate-400 text-lg">
              Controle total • Analytics avançado • Depósitos e Saques
            </p>
          </div>
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => setShowAnalytics(!showAnalytics)}
            className="p-4 bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 rounded-xl transition-all border border-purple-500/30 hover:border-purple-400/50"
            title="Ver analytics"
          >
            <BarChart3 className="w-6 h-6" />
          </button>
          {isEditing ? (
            <>
              <button
                onClick={handleSave}
                className="p-4 bg-green-500/20 hover:bg-green-500/30 text-green-400 rounded-xl transition-all border border-green-500/30 hover:border-green-400/50"
                title="Salvar alterações"
              >
                <Save className="w-6 h-6" />
              </button>
              <button
                onClick={handleCancel}
                className="p-4 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-xl transition-all border border-red-500/30 hover:border-red-400/50"
                title="Cancelar edição"
              >
                <X className="w-6 h-6" />
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => setShowPresets(!showPresets)}
                className="p-4 bg-slate-500/20 hover:bg-slate-500/30 text-slate-400 rounded-xl transition-all border border-slate-500/30 hover:border-slate-400/50"
                title="Configurações rápidas"
              >
                <Settings className="w-6 h-6" />
              </button>
              <button
                onClick={handleReset}
                className="p-4 bg-orange-500/20 hover:bg-orange-500/30 text-orange-400 rounded-xl transition-all border border-orange-500/30 hover:border-orange-400/50"
                title="Reset completo"
              >
                <RotateCcw className="w-6 h-6" />
              </button>
              <button
                onClick={() => setIsEditing(true)}
                className="p-4 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 rounded-xl transition-all border border-cyan-500/30 hover:border-cyan-400/50"
                title="Editar valores"
              >
                <Edit3 className="w-6 h-6" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Deposit/Withdraw Section */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <div className="bg-green-500/20 rounded-2xl p-6 border border-green-500/30">
          <div className="flex items-center gap-3 mb-4">
            <ArrowUp className="w-6 h-6 text-green-400" />
            <h4 className="text-white font-bold text-xl">💰 Depositar</h4>
          </div>
          <div className="flex gap-3">
            <input
              type="number"
              value={depositAmount}
              onChange={(e) => setDepositAmount(e.target.value)}
              placeholder="Valor do depósito"
              className="flex-1 bg-white/10 text-white rounded-lg px-4 py-3 border border-white/20 focus:border-green-400 focus:outline-none"
            />
            <button
              onClick={handleDeposit}
              disabled={!depositAmount || parseFloat(depositAmount) <= 0}
              className="px-6 py-3 bg-green-500/30 hover:bg-green-500/40 text-green-400 rounded-lg font-bold transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="bg-red-500/20 rounded-2xl p-6 border border-red-500/30">
          <div className="flex items-center gap-3 mb-4">
            <ArrowDown className="w-6 h-6 text-red-400" />
            <h4 className="text-white font-bold text-xl">💸 Sacar</h4>
          </div>
          <div className="flex gap-3">
            <input
              type="number"
              value={withdrawAmount}
              onChange={(e) => setWithdrawAmount(e.target.value)}
              placeholder="Valor do saque"
              max={bankData.currentBank}
              className="flex-1 bg-white/10 text-white rounded-lg px-4 py-3 border border-white/20 focus:border-red-400 focus:outline-none"
            />
            <button
              onClick={handleWithdraw}
              disabled={!withdrawAmount || parseFloat(withdrawAmount) <= 0 || parseFloat(withdrawAmount) > bankData.currentBank}
              className="px-6 py-3 bg-red-500/30 hover:bg-red-500/40 text-red-400 rounded-lg font-bold transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Minus className="w-5 h-5" />
            </button>
          </div>
          <p className="text-red-300 text-sm mt-2">
            Saldo disponível: {formatCurrency(bankData.currentBank)}
          </p>
        </div>
      </div>

      {/* Configurações Rápidas */}
      {showPresets && (
        <div className="mb-8 p-6 bg-slate-800/30 rounded-2xl border border-cyan-500/30">
          <h4 className="text-white font-bold text-xl mb-6">⚙️ Configurações Rápidas</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              onClick={() => {
                setPresetValues('conservative');
                setSessionStartBank(100);
                setShowPresets(false);
              }}
              className="p-6 bg-green-500/20 hover:bg-green-500/30 text-green-400 rounded-xl transition-all border border-green-500/30 hover:border-green-400/50"
            >
              <div className="font-bold text-lg">💚 Conservador</div>
              <div className="text-sm opacity-80 mt-2">R$ 100 • Entrada R$ 5</div>
            </button>
            <button
              onClick={() => {
                setPresetValues('moderate');
                setSessionStartBank(500);
                setShowPresets(false);
              }}
              className="p-6 bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 rounded-xl transition-all border border-yellow-500/30 hover:border-yellow-400/50"
            >
              <div className="font-bold text-lg">🟡 Moderado</div>
              <div className="text-sm opacity-80 mt-2">R$ 500 • Entrada R$ 25</div>
            </button>
            <button
              onClick={() => {
                setPresetValues('aggressive');
                setSessionStartBank(1000);
                setShowPresets(false);
              }}
              className="p-6 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-xl transition-all border border-red-500/30 hover:border-red-400/50"
            >
              <div className="font-bold text-lg">🔴 Agressivo</div>
              <div className="text-sm opacity-80 mt-2">R$ 1000 • Entrada R$ 50</div>
            </button>
          </div>
        </div>
      )}

      {/* Banca Atual com Lucro do Dia */}
      <div className="bg-gradient-to-r from-cyan-500/20 to-purple-500/20 rounded-2xl p-8 mb-8 border border-cyan-500/30">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-cyan-300 text-lg mb-2">💰 Banca Atual</p>
            <p className={`text-5xl font-black ${getStatusColor()}`}>
              {formatCurrency(bankData.currentBank)}
            </p>
            <p className="text-white/60 text-lg mt-2">
              Início hoje: {formatCurrency(sessionStartBank)}
            </p>
          </div>
          <div className="text-right">
            <div className={`flex items-center gap-3 ${profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {profit >= 0 ? <TrendingUp className="w-8 h-8" /> : <TrendingDown className="w-8 h-8" />}
              <div>
                <p className="font-black text-3xl">
                  {formatCurrency(Math.abs(profit))}
                </p>
                <p className="text-lg">
                  {profitPercentage >= 0 ? '+' : ''}{profitPercentage.toFixed(1)}%
                </p>
              </div>
            </div>
            <div className={`flex items-center gap-2 mt-3 ${riskLevel.color}`}>
              <AlertTriangle className="w-5 h-5" />
              <span className="text-lg">Risco: {riskLevel.level}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Resto do componente permanece igual... */}
      {/* Estatísticas Principais */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-green-500/20 rounded-xl p-6 text-center border border-green-500/30">
          <p className="text-green-400 text-sm mb-2">💰 Lucro Total</p>
          <p className="text-green-400 text-2xl font-bold">{formatCurrency(statistics.totalProfit)}</p>
        </div>

        <div className="bg-red-500/20 rounded-xl p-6 text-center border border-red-500/30">
          <p className="text-red-400 text-sm mb-2">📉 Total Apostado</p>
          <p className="text-red-400 text-2xl font-bold">{formatCurrency(totalApostado)}</p>
        </div>

        <div className="bg-blue-500/20 rounded-xl p-6 text-center border border-blue-500/30">
          <p className="text-blue-400 text-sm mb-2">🏆 Vitórias</p>
          <p className="text-blue-400 text-2xl font-bold">{totalGreens}</p>
        </div>

        <div className="bg-slate-500/20 rounded-xl p-6 text-center border border-slate-500/30">
          <p className="text-slate-400 text-sm mb-2">❌ Perdas</p>
          <p className="text-slate-400 text-2xl font-bold">{totalReds}</p>
        </div>
      </div>

      {/* Controles Manuais de Entrada */}
      <div className="mb-8">
        <h4 className="text-white font-bold text-xl mb-6 flex items-center gap-3">
          <Zap className="w-6 h-6 text-cyan-400" />
          Controles Manuais
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-green-500/20 rounded-xl p-6 border border-green-500/30">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-green-400 font-bold text-3xl">{totalGreens}</p>
                <p className="text-white/80 text-lg">Verdes</p>
              </div>
              <button
                onClick={() => addEntry('GREEN', 0)}
                className="p-4 bg-green-500/30 hover:bg-green-500/40 text-green-400 rounded-xl transition-all hover:scale-105"
              >
                <Plus className="w-8 h-8" />
              </button>
            </div>
            <p className="text-green-300 text-sm">
              +{formatCurrency(bankData.entryValue)} por verde
            </p>
          </div>

          <div className="bg-red-500/20 rounded-xl p-6 border border-red-500/30">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-red-400 font-bold text-3xl">{totalReds}</p>
                <p className="text-white/80 text-lg">Reds</p>
              </div>
              <button
                onClick={() => addEntry('RED', 0)}
                className="p-4 bg-red-500/30 hover:bg-red-500/40 text-red-400 rounded-xl transition-all hover:scale-105"
              >
                <Minus className="w-8 h-8" />
              </button>
            </div>
            <p className="text-red-300 text-sm">
              -{formatCurrency(bankData.entryValue)} por red
            </p>
          </div>
        </div>
      </div>

      {/* Progresso para Meta */}
      {bankData.target > bankData.initialBank && (
        <div className="mb-8">
          <div className="flex justify-between text-lg text-white/80 mb-3">
            <span>🎯 Progresso para Meta</span>
            <span>{getProgress().toFixed(1)}%</span>
          </div>
          <div className="h-6 bg-slate-800/50 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-cyan-500 to-purple-600 transition-all duration-1000 ease-out"
              style={{ width: `${Math.min(100, getProgress())}%` }}
            />
          </div>
        </div>
      )}

      {/* Configurações Editáveis */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[
          { key: 'initialBank', label: 'Banca Inicial', icon: Wallet, color: 'text-cyan-400' },
          { key: 'target', label: 'Meta', icon: Target, color: 'text-green-400' },
          { key: 'stopLoss', label: 'Stop Loss', icon: TrendingDown, color: 'text-red-400' },
          { key: 'stopWin', label: 'Stop Win', icon: TrendingUp, color: 'text-green-400' },
        ].map(({ key, label, icon: Icon, color }) => (
          <div key={key} className="bg-slate-800/30 rounded-xl p-6 border border-slate-700/30">
            <div className="flex items-center gap-3 mb-3">
              <Icon className={`w-6 h-6 ${color}`} />
              <span className="text-white/80 text-lg">{label}</span>
            </div>
            {isEditing ? (
              <input
                type="number"
                min="0"
                step="0.01"
                value={editValues[key as keyof BankManagement]}
                onChange={(e) => setEditValues(prev => ({
                  ...prev,
                  [key]: parseFloat(e.target.value) || 0
                }))}
                className="w-full bg-white/10 text-white rounded-lg px-4 py-3 text-lg border border-white/20 focus:border-cyan-400 focus:outline-none"
                placeholder="0.00"
              />
            ) : (
              <p className="text-white font-bold text-2xl">
                {formatCurrency(bankData[key as keyof BankManagement])}
              </p>
            )}
          </div>
        ))}
      </div>

      {/* Valor de Entrada */}
      <div className="mt-6 bg-cyan-500/20 rounded-xl p-6 border border-cyan-500/30">
        <div className="flex items-center gap-3 mb-3">
          <Target className="w-6 h-6 text-cyan-400" />
          <span className="text-white/80 text-lg">💎 Valor por Entrada</span>
        </div>
        {isEditing ? (
          <input
            type="number"
            min="0"
            step="0.01"
            value={editValues.entryValue}
            onChange={(e) => setEditValues(prev => ({
              ...prev,
              entryValue: parseFloat(e.target.value) || 0
            }))}
            className="w-full bg-white/10 text-white rounded-lg px-4 py-3 text-2xl font-bold border border-white/20 focus:border-cyan-400 focus:outline-none"
            placeholder="0.00"
          />
        ) : (
          <p className="text-cyan-400 text-3xl font-black">
            {formatCurrency(bankData.entryValue)}
          </p>
        )}
      </div>

      {/* Alertas de Segurança */}
      {bankData.currentBank > 0 && (
        <div className="mt-8 space-y-4">
          {bankData.currentBank <= bankData.stopLoss && (
            <div className="bg-red-500/20 border border-red-500/30 rounded-xl p-6">
              <div className="flex items-center gap-4">
                <AlertTriangle className="w-8 h-8 text-red-400" />
                <div>
                  <p className="text-red-400 font-bold text-2xl">🚨 Stop Loss Atingido!</p>
                  <p className="text-red-300 text-lg">Considere parar as operações</p>
                </div>
              </div>
            </div>
          )}
          {bankData.currentBank >= bankData.stopWin && (
            <div className="bg-green-500/20 border border-green-500/30 rounded-xl p-6">
              <div className="flex items-center gap-4">
                <Target className="w-8 h-8 text-green-400" />
                <div>
                  <p className="text-green-400 font-bold text-2xl">🎉 Stop Win Atingido!</p>
                  <p className="text-green-300 text-lg">Parabéns! Meta alcançada</p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};