import React, { useEffect, useState } from 'react';
import { 
  Brain, 
  Activity, 
  Target, 
  TrendingUp, 
  BarChart3, 
  Zap,
  PlayCircle,
  PauseCircle,
  RotateCcw,
  Sparkles,
  Clock,
  Shield
} from 'lucide-react';

interface MLAnalyzerProps {
  selectedMode: 'normal' | 'medium' | 'advanced';
  currentPrediction: 'player' | 'banker' | 'tie' | null;
  confidence: number;
  isAnalyzing: boolean;
  analysisData: any;
  onToggleAnalysis: () => void;
  onReset: () => void;
  lastUpdate?: Date;
}

export const MLAnalyzer: React.FC<MLAnalyzerProps> = ({
  selectedMode,
  currentPrediction,
  confidence,
  isAnalyzing,
  analysisData,
  onToggleAnalysis,
  onReset,
  lastUpdate
}) => {
  const [countdown, setCountdown] = useState(30);

  useEffect(() => {
    if (isAnalyzing) {
      const interval = setInterval(() => {
        setCountdown(prev => prev > 0 ? prev - 1 : 30);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isAnalyzing]);

  const getPredictionColor = () => {
    switch (currentPrediction) {
      case 'player': return 'from-cyan-400 to-blue-600';
      case 'banker': return 'from-red-400 to-pink-600';
      case 'tie': return 'from-yellow-400 to-orange-600';
      default: return 'from-slate-400 to-slate-600';
    }
  };

  const getPredictionIcon = () => {
    switch (currentPrediction) {
      case 'player': return '👤';
      case 'banker': return '🏦';
      case 'tie': return '🤝';
      default: return '🎯';
    }
  };

  const getPredictionName = () => {
    switch (currentPrediction) {
      case 'player': return 'PLAYER';
      case 'banker': return 'BANKER';
      case 'tie': return 'TIE';
      default: return 'AGUARDANDO';
    }
  };

  const getConfidenceLevel = () => {
    if (confidence >= 80) return { level: 'MUITO ALTA', color: 'text-emerald-400', icon: '🔥' };
    if (confidence >= 70) return { level: 'ALTA', color: 'text-green-400', icon: '⚡' };
    if (confidence >= 60) return { level: 'MÉDIA', color: 'text-yellow-400', icon: '⭐' };
    return { level: 'BAIXA', color: 'text-red-400', icon: '⚠️' };
  };

  const confidenceLevel = getConfidenceLevel();

  return (
    <div className="space-y-8">
      {/* Main Prediction Display */}
      <div className="relative bg-slate-900/50 backdrop-blur-xl rounded-3xl p-8 border border-slate-700/50 shadow-2xl overflow-hidden">
        {/* Background Glow */}
        <div className={`absolute inset-0 bg-gradient-to-br ${getPredictionColor()} opacity-5 rounded-3xl`} />
        
        {/* Animated Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)`,
            backgroundSize: '40px 40px',
            animation: 'float 6s ease-in-out infinite'
          }} />
        </div>

        <div className="relative z-10">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${getPredictionColor()} flex items-center justify-center shadow-lg`}>
                  <Brain className="w-6 h-6 text-white" />
                </div>
                {isAnalyzing && (
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-cyan-400 to-blue-600 animate-ping opacity-30" />
                )}
              </div>
              <div>
                <h3 className="text-white font-black text-2xl">PREDIÇÃO ML</h3>
                <p className="text-slate-400">Sistema Neural Avançado</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className={`px-4 py-2 rounded-full border ${isAnalyzing ? 'border-green-500/50 bg-green-500/10' : 'border-slate-600 bg-slate-800/50'}`}>
                <div className="flex items-center gap-2">
                  <div className={`w-2 h-2 rounded-full ${isAnalyzing ? 'bg-green-400 animate-pulse' : 'bg-slate-500'}`} />
                  <span className="text-white text-sm font-bold">
                    {isAnalyzing ? 'ATIVO' : 'STANDBY'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Main Prediction Circle */}
          <div className="flex justify-center mb-8">
            <div className="relative">
              {/* Outer Ring */}
              <div className={`w-64 h-64 rounded-full bg-gradient-to-br ${getPredictionColor()} p-1 shadow-2xl`}>
                {/* Progress Ring */}
                <div className="relative w-full h-full bg-slate-900 rounded-full flex items-center justify-center">
                  <svg className="absolute inset-0 w-full h-full -rotate-90">
                    <circle
                      cx="50%"
                      cy="50%"
                      r="45%"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      className="text-slate-700"
                    />
                    <circle
                      cx="50%"
                      cy="50%"
                      r="45%"
                      fill="none"
                      stroke="url(#gradient)"
                      strokeWidth="3"
                      strokeDasharray={`${confidence * 2.83} 283`}
                      className="transition-all duration-1000"
                    />
                    <defs>
                      <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#06b6d4" />
                        <stop offset="100%" stopColor="#3b82f6" />
                      </linearGradient>
                    </defs>
                  </svg>
                  
                  {/* Content */}
                  <div className="text-center z-10">
                    <div className="text-6xl mb-2">{getPredictionIcon()}</div>
                    <div className={`text-3xl font-black text-transparent bg-gradient-to-br ${getPredictionColor()} bg-clip-text mb-2`}>
                      {getPredictionName()}
                    </div>
                    <div className="text-4xl font-black text-white mb-1">
                      {confidence.toFixed(0)}%
                    </div>
                    <div className={`text-sm font-bold ${confidenceLevel.color} flex items-center justify-center gap-1`}>
                      <span>{confidenceLevel.icon}</span>
                      <span>{confidenceLevel.level}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Pulse Effect */}
              {isAnalyzing && currentPrediction && (
                <div className={`absolute inset-0 rounded-full bg-gradient-to-br ${getPredictionColor()} animate-ping opacity-20`} />
              )}
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-slate-800/50 rounded-2xl p-4 text-center border border-slate-700/30">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span className="text-slate-400 text-xs">Modo</span>
              </div>
              <div className="text-white font-bold capitalize">{selectedMode}</div>
            </div>

            <div className="bg-slate-800/50 rounded-2xl p-4 text-center border border-slate-700/30">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Clock className="w-4 h-4 text-yellow-400" />
                <span className="text-slate-400 text-xs">Próxima</span>
              </div>
              <div className="text-white font-bold">{countdown}s</div>
            </div>

            <div className="bg-slate-800/50 rounded-2xl p-4 text-center border border-slate-700/30">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Target className="w-4 h-4 text-green-400" />
                <span className="text-slate-400 text-xs">Acertos</span>
              </div>
              <div className="text-white font-bold">78.3%</div>
            </div>

            <div className="bg-slate-800/50 rounded-2xl p-4 text-center border border-slate-700/30">
              <div className="flex items-center justify-center gap-2 mb-2">
                <BarChart3 className="w-4 h-4 text-purple-400" />
                <span className="text-slate-400 text-xs">Padrões</span>
              </div>
              <div className="text-white font-bold">8</div>
            </div>
          </div>

          {/* Control Buttons */}
          <div className="flex flex-wrap gap-4 justify-center">
            <button
              onClick={onToggleAnalysis}
              className={`
                flex items-center gap-3 px-8 py-4 rounded-2xl font-bold text-lg transition-all duration-300 shadow-lg
                ${isAnalyzing 
                  ? 'bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white shadow-red-500/25' 
                  : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white shadow-cyan-500/25'
                }
                hover:scale-105 transform
              `}
            >
              {isAnalyzing ? (
                <>
                  <PauseCircle className="w-6 h-6" />
                  <span>PAUSAR IA</span>
                </>
              ) : (
                <>
                  <PlayCircle className="w-6 h-6" />
                  <span>ATIVAR IA</span>
                </>
              )}
            </button>

            <button
              onClick={onReset}
              className="flex items-center gap-3 px-6 py-4 bg-slate-700 hover:bg-slate-600 text-white rounded-2xl font-bold text-lg transition-all hover:scale-105 transform shadow-lg"
            >
              <RotateCcw className="w-5 h-5" />
              <span>RESET</span>
            </button>

            <button className="flex items-center gap-3 px-6 py-4 bg-gradient-to-r from-purple-500 to-violet-600 hover:from-purple-600 hover:to-violet-700 text-white rounded-2xl font-bold text-lg transition-all hover:scale-105 transform shadow-lg shadow-purple-500/25">
              <Sparkles className="w-5 h-5" />
              <span>BOOST</span>
            </button>
          </div>
        </div>
      </div>

      {/* Analysis Details */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Pattern Analysis */}
        <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-slate-700/50 shadow-xl">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-violet-600 rounded-xl flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-white" />
            </div>
            <h4 className="text-white font-bold text-lg">Análise de Padrões</h4>
          </div>

          <div className="space-y-4">
            {[
              { name: 'Sequência Player', value: 73, color: 'bg-cyan-500' },
              { name: 'Sequência Banker', value: 68, color: 'bg-red-500' },
              { name: 'Padrão Alternado', value: 45, color: 'bg-yellow-500' },
              { name: 'Streak Detection', value: 82, color: 'bg-purple-500' }
            ].map((pattern, index) => (
              <div key={index}>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-slate-300">{pattern.name}</span>
                  <span className="text-white font-bold">{pattern.value}%</span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-2">
                  <div 
                    className={`${pattern.color} h-2 rounded-full transition-all duration-1000`}
                    style={{ width: `${pattern.value}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* System Status */}
        <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-slate-700/50 shadow-xl">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <h4 className="text-white font-bold text-lg">Status do Sistema</h4>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
              <span className="text-slate-300">TipMiner API</span>
              <span className="text-green-400 font-bold">✓ Online</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
              <span className="text-slate-300">ML Algorithm</span>
              <span className="text-green-400 font-bold">✓ Ativo</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
              <span className="text-slate-300">Pattern Scanner</span>
              <span className="text-yellow-400 font-bold">⟳ Processando</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg">
              <span className="text-slate-300">Voice Alerts</span>
              <span className="text-green-400 font-bold">✓ Pronto</span>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-10px) rotate(180deg); }
        }
      `}</style>
    </div>
  );
};