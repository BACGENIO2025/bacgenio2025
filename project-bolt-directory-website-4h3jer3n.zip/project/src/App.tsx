import React, { useState, useEffect } from 'react';
import { BankManagement } from './types';
import { GameModeSelector } from './components/GameModeSelector';
import { MLAnalyzer } from './components/MLAnalyzer';
import { ImprovedBankManager } from './components/ImprovedBankManager';
import { VoiceSettings } from './components/VoiceSettings';
import { FootballSection } from './components/FootballSection';
import { LoginForm } from './components/LoginForm';
import { NotificationToast } from './components/NotificationToast';
import { useBankManagement } from './hooks/useBankManagement';
import { useMLAnalysis } from './hooks/useMLAnalysis';
import { useVoiceNotifications } from './hooks/useVoiceNotifications';
import { useAuth } from './hooks/useAuth';
import { useTelegram } from './hooks/useTelegram';
import { Brain, Zap, Settings, Volume2, VolumeX, Sparkles, Target, TrendingUp, LogOut, User, FolderRoot as Football } from 'lucide-react';

export default function App() {
  const [selectedMode, setSelectedMode] = useState<'normal' | 'medium' | 'advanced'>('normal');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showBankManager, setShowBankManager] = useState(false);
  const [showVoiceSettings, setShowVoiceSettings] = useState(false);
  const [showFootball, setShowFootball] = useState(false);
  const [notifications, setNotifications] = useState<Array<{id: string, message: string, type: 'success' | 'error' | 'info'}>>([]);

  const { user, login, logout, isLoading } = useAuth();
  const { sendTelegramMessage } = useTelegram();

  const {
    bankData,
    updateBank,
    resetBank,
    setPresetValues,
    getProgress,
    getStatusColor,
    getRiskLevel,
    deposit,
    withdraw
  } = useBankManagement();

  const {
    currentPrediction,
    confidence,
    isAnalyzing: mlAnalyzing,
    analysisData,
    toggleAnalysis,
    resetAnalysis,
    lastUpdate
  } = useMLAnalysis(selectedMode);

  const {
    isEnabled: voiceEnabled,
    toggle: toggleVoice,
    speak,
    setVoice,
    setRate,
    setVolume,
    currentSettings
  } = useVoiceNotifications();

  // Auto-announce predictions
  useEffect(() => {
    if (currentPrediction && voiceEnabled && confidence > 70) {
      const message = `Nova predição Genio API: ${currentPrediction.toUpperCase()} com ${confidence.toFixed(0)}% de confiança`;
      speak(message);
      
      // Enviar para Telegram se configurado
      sendTelegramMessage(`🤖 GENIO API - Nova Predição\n${currentPrediction.toUpperCase()} - ${confidence.toFixed(0)}% confiança`);
    }
  }, [currentPrediction, confidence, voiceEnabled, speak, sendTelegramMessage]);

  const addNotification = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Date.now().toString();
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 3000);
  };

  const handleDeposit = (amount: number) => {
    deposit(amount);
    addNotification(`💰 Depósito de R$ ${amount.toFixed(2)} realizado com sucesso!`, 'success');
    sendTelegramMessage(`💰 Depósito realizado: R$ ${amount.toFixed(2)}\nNova banca: R$ ${(bankData.currentBank + amount).toFixed(2)}`);
  };

  const handleWithdraw = (amount: number) => {
    if (amount <= bankData.currentBank) {
      withdraw(amount);
      addNotification(`💸 Saque de R$ ${amount.toFixed(2)} realizado com sucesso!`, 'success');
      sendTelegramMessage(`💸 Saque realizado: R$ ${amount.toFixed(2)}\nNova banca: R$ ${(bankData.currentBank - amount).toFixed(2)}`);
    } else {
      addNotification('❌ Saldo insuficiente para saque!', 'error');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-2xl mx-auto mb-4">
            <Brain className="w-8 h-8 text-white animate-pulse" />
          </div>
          <p className="text-white text-xl">Carregando Genio API...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginForm onLogin={login} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 relative overflow-hidden">
      {/* Animated Grid Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-violet-950/20 to-cyan-950/20">
        <div className="absolute inset-0" style={{
          backgroundImage: `
            linear-gradient(rgba(59, 130, 246, 0.1) 1px, transparent 1px),
            linear-gradient(90deg, rgba(59, 130, 246, 0.1) 1px, transparent 1px)
          `,
          backgroundSize: '50px 50px',
          animation: 'grid-move 20s linear infinite'
        }} />
      </div>

      {/* Glow Effects */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-pink-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-yellow-500/10 rounded-full blur-3xl animate-pulse delay-2000" />

      {/* Notifications */}
      <div className="fixed top-4 right-4 z-50 space-y-2">
        {notifications.map(notification => (
          <NotificationToast
            key={notification.id}
            message={notification.message}
            type={notification.type}
            onClose={() => setNotifications(prev => prev.filter(n => n.id !== notification.id))}
          />
        ))}
      </div>

      <div className="relative z-10 min-h-screen p-4 lg:p-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="w-16 h-16 bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-2xl">
                  <Brain className="w-8 h-8 text-white" />
                </div>
                <div className="absolute inset-0 bg-gradient-to-br from-cyan-400 via-blue-500 to-purple-600 rounded-2xl blur-lg opacity-50 animate-pulse" />
              </div>
              <div className="text-left">
                <h1 className="text-4xl lg:text-6xl font-black bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
                  GENIO API
                </h1>
                <div className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-cyan-400" />
                  <span className="text-xl font-bold text-cyan-400">ML ANALYZER</span>
                  <span className="px-3 py-1 bg-gradient-to-r from-pink-500 to-violet-500 text-white text-sm font-bold rounded-full">
                    v4.0 PRO
                  </span>
                </div>
              </div>
            </div>

            {/* User Info & Controls */}
            <div className="flex items-center gap-4">
              <button
                onClick={() => setShowFootball(!showFootball)}
                className="flex items-center gap-3 px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white rounded-xl font-bold transition-all hover:scale-105 shadow-lg"
              >
                <Football className="w-5 h-5" />
                <span>FUTEBOL</span>
              </button>

              <div className="flex items-center gap-3 bg-slate-900/50 backdrop-blur-xl rounded-xl px-4 py-3 border border-slate-700/50">
                <User className="w-5 h-5 text-cyan-400" />
                <span className="text-white font-semibold">{user.displayName || user.email}</span>
                <button
                  onClick={logout}
                  className="p-2 text-red-400 hover:text-red-300 transition-colors"
                  title="Logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          <p className="text-center text-slate-400 text-lg max-w-2xl mx-auto leading-relaxed mb-12">
            Sistema avançado de predição com <span className="text-cyan-400 font-semibold">Genio API</span>, 
            análise de padrões em tempo real e <span className="text-pink-400 font-semibold">IA adaptativa</span>
          </p>

          {/* Football Section */}
          {showFootball && (
            <div className="mb-12">
              <FootballSection onNotification={addNotification} />
            </div>
          )}

          {/* Game Mode Selector */}
          <div className="mb-12">
            <GameModeSelector 
              selectedMode={selectedMode} 
              onModeChange={setSelectedMode} 
            />
          </div>

          {/* Main Control Panel */}
          <div className="grid lg:grid-cols-3 gap-8 mb-12">
            {/* ML Analyzer */}
            <div className="lg:col-span-2">
              <MLAnalyzer
                selectedMode={selectedMode}
                currentPrediction={currentPrediction}
                confidence={confidence}
                isAnalyzing={isAnalyzing || mlAnalyzing}
                analysisData={analysisData}
                onToggleAnalysis={() => {
                  toggleAnalysis();
                  setIsAnalyzing(!isAnalyzing);
                }}
                onReset={resetAnalysis}
                lastUpdate={lastUpdate}
              />
            </div>

            {/* Control Panel */}
            <div className="space-y-6">
              {/* Analysis Status */}
              <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-cyan-500/20 shadow-2xl">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-white font-bold text-lg">Status do Sistema</h3>
                  <div className={`w-3 h-3 rounded-full ${isAnalyzing || mlAnalyzing ? 'bg-green-400 animate-pulse' : 'bg-slate-600'}`} />
                </div>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Genio API:</span>
                    <span className="text-green-400 font-semibold">✓ Online</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Modo Ativo:</span>
                    <span className="text-cyan-400 font-semibold capitalize">{selectedMode}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">IA Status:</span>
                    <span className={`font-semibold ${isAnalyzing || mlAnalyzing ? 'text-green-400' : 'text-slate-400'}`}>
                      {isAnalyzing || mlAnalyzing ? 'Analisando' : 'Standby'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Última Atualização:</span>
                    <span className="text-white font-mono text-xs">
                      {lastUpdate ? new Date(lastUpdate).toLocaleTimeString() : '--:--:--'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-purple-500/20 shadow-2xl">
                <h3 className="text-white font-bold text-lg mb-4">Ações Rápidas</h3>
                <div className="space-y-3">
                  <button
                    onClick={() => setShowBankManager(!showBankManager)}
                    className="w-full p-4 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 hover:from-cyan-500/30 hover:to-blue-500/30 text-cyan-400 rounded-xl transition-all border border-cyan-500/30 hover:border-cyan-400/50 group"
                  >
                    <div className="flex items-center justify-center gap-3">
                      <Target className="w-5 h-5 group-hover:scale-110 transition-transform" />
                      <span className="font-semibold">Gestão de Banca</span>
                    </div>
                  </button>
                  
                  <button
                    onClick={() => setShowVoiceSettings(!showVoiceSettings)}
                    className="w-full p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 hover:from-purple-500/30 hover:to-pink-500/30 text-purple-400 rounded-xl transition-all border border-purple-500/30 hover:border-purple-400/50 group"
                  >
                    <div className="flex items-center justify-center gap-3">
                      {voiceEnabled ? (
                        <Volume2 className="w-5 h-5 group-hover:scale-110 transition-transform" />
                      ) : (
                        <VolumeX className="w-5 h-5 group-hover:scale-110 transition-transform" />
                      )}
                      <span className="font-semibold">Notificações Voz</span>
                    </div>
                  </button>
                </div>
              </div>

              {/* Performance Stats */}
              <div className="bg-slate-900/50 backdrop-blur-xl rounded-2xl p-6 border border-emerald-500/20 shadow-2xl">
                <div className="flex items-center gap-3 mb-4">
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                  <h3 className="text-white font-bold text-lg">Performance</h3>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400 text-sm">Precisão Atual</span>
                    <span className="text-emerald-400 font-bold">{confidence.toFixed(1)}%</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-emerald-500 to-cyan-500 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${confidence}%` }}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div className="text-center">
                      <p className="text-slate-400 text-xs">Predições</p>
                      <p className="text-white font-bold text-lg">247</p>
                    </div>
                    <div className="text-center">
                      <p className="text-slate-400 text-xs">Acertos</p>
                      <p className="text-emerald-400 font-bold text-lg">78.3%</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Bank Manager */}
          {showBankManager && (
            <div className="mb-12">
              <ImprovedBankManager
                bankData={bankData}
                updateBank={updateBank}
                resetBank={resetBank}
                setPresetValues={setPresetValues}
                getProgress={getProgress}
                getStatusColor={getStatusColor}
                getRiskLevel={getRiskLevel}
                onAutoEntryToggle={() => {}}
                autoEntryEnabled={false}
                onDeposit={handleDeposit}
                onWithdraw={handleWithdraw}
              />
            </div>
          )}

          {/* Voice Settings */}
          {showVoiceSettings && (
            <div className="mb-12">
              <VoiceSettings
                isEnabled={voiceEnabled}
                onToggle={toggleVoice}
                currentSettings={currentSettings}
                onVoiceChange={setVoice}
                onRateChange={setRate}
                onVolumeChange={setVolume}
              />
            </div>
          )}

          {/* Footer */}
          <div className="text-center mt-16 pb-8">
            <div className="inline-flex items-center gap-2 px-6 py-3 bg-slate-900/30 backdrop-blur-xl rounded-full border border-slate-700/50">
              <Zap className="w-4 h-4 text-yellow-400" />
              <span className="text-slate-400 text-sm">
                Powered by Genio API • Real-time Analysis • v4.0 Professional
              </span>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes grid-move {
          0% { transform: translate(0, 0); }
          100% { transform: translate(50px, 50px); }
        }
      `}</style>
    </div>
  );
}