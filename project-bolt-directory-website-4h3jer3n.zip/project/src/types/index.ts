export interface BankManagement {
  initialBank: number;
  currentBank: number;
  target: number;
  stopLoss: number;
  stopWin: number;
  entryValue: number;
}

export interface GameMode {
  id: 'normal' | 'medium' | 'advanced';
  name: string;
  description: string;
  riskLevel: string;
  bankPercentage: string;
  accuracy: string;
}

export interface PredictionResult {
  prediction: 'player' | 'banker' | 'tie';
  confidence: number;
  timestamp: Date;
  mode: 'normal' | 'medium' | 'advanced';
}

export interface AnalysisPattern {
  name: string;
  confidence: number;
  trend: 'up' | 'down' | 'stable';
  description?: string;
}

export interface VoiceNotificationSettings {
  enabled: boolean;
  voice: SpeechSynthesisVoice | null;
  rate: number;
  volume: number;
  pitch: number;
}

export interface SystemStatus {
  isAnalyzing: boolean;
  lastUpdate: Date | null;
  apiStatus: 'online' | 'offline' | 'error';
  mlStatus: 'active' | 'standby' | 'error';
  patternScannerStatus: 'processing' | 'idle' | 'error';
  voiceStatus: 'ready' | 'disabled' | 'error';
}

export interface EntryRecord {
  id: string;
  timestamp: Date;
  type: 'GREEN' | 'RED';
  amount: number;
  balance: number;
  galeLevel: number;
  mode: 'normal' | 'medium' | 'advanced';
}

export interface DailySession {
  date: string;
  initialBank: number;
  finalBank: number;
  profit: number;
  profitPercentage: number;
  totalEntries: number;
  greens: number;
  reds: number;
  winRate: number;
  mode: 'normal' | 'medium' | 'advanced';
}

export interface BankStatistics {
  totalProfit: number;
  totalLoss: number;
  netProfit: number;
  totalEntries: number;
  winRate: number;
  avgWin: number;
  avgLoss: number;
  maxWin: number;
  maxLoss: number;
  profitFactor: number;
  bestDay: number;
  worstDay: number;
  consecutiveWins: number;
  consecutiveLosses: number;
}