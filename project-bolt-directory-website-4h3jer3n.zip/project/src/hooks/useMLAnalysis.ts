import { useState, useEffect, useCallback } from 'react';

interface AnalysisData {
  patterns: Array<{
    name: string;
    confidence: number;
    trend: 'up' | 'down' | 'stable';
  }>;
  history: Array<{
    timestamp: Date;
    prediction: 'player' | 'banker' | 'tie';
    confidence: number;
    result?: 'win' | 'loss';
  }>;
  statistics: {
    totalPredictions: number;
    correctPredictions: number;
    accuracy: number;
    streak: number;
  };
}

export const useMLAnalysis = (mode: 'normal' | 'medium' | 'advanced') => {
  const [currentPrediction, setCurrentPrediction] = useState<'player' | 'banker' | 'tie' | null>(null);
  const [confidence, setConfidence] = useState(0);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [analysisData, setAnalysisData] = useState<AnalysisData>({
    patterns: [
      { name: 'Sequência Player', confidence: 73, trend: 'up' },
      { name: 'Sequência Banker', confidence: 68, trend: 'down' },
      { name: 'Padrão Alternado', confidence: 45, trend: 'stable' },
      { name: 'Streak Detection', confidence: 82, trend: 'up' }
    ],
    history: [],
    statistics: {
      totalPredictions: 247,
      correctPredictions: 193,
      accuracy: 78.3,
      streak: 5
    }
  });

  // Simulação de análise ML
  const generatePrediction = useCallback(() => {
    const predictions: ('player' | 'banker' | 'tie')[] = ['player', 'banker', 'tie'];
    const randomPrediction = predictions[Math.floor(Math.random() * predictions.length)];
    
    // Ajustar confiança baseado no modo
    let baseConfidence = 60;
    switch (mode) {
      case 'normal':
        baseConfidence = 65 + Math.random() * 15; // 65-80%
        break;
      case 'medium':
        baseConfidence = 70 + Math.random() * 15; // 70-85%
        break;
      case 'advanced':
        baseConfidence = 75 + Math.random() * 15; // 75-90%
        break;
    }

    setCurrentPrediction(randomPrediction);
    setConfidence(baseConfidence);
    setLastUpdate(new Date());

    // Adicionar ao histórico
    setAnalysisData(prev => ({
      ...prev,
      history: [
        {
          timestamp: new Date(),
          prediction: randomPrediction,
          confidence: baseConfidence
        },
        ...prev.history.slice(0, 49) // Manter últimas 50 predições
      ]
    }));
  }, [mode]);

  // Atualizar padrões periodicamente
  const updatePatterns = useCallback(() => {
    setAnalysisData(prev => ({
      ...prev,
      patterns: prev.patterns.map(pattern => ({
        ...pattern,
        confidence: Math.max(20, Math.min(95, pattern.confidence + (Math.random() - 0.5) * 10)),
        trend: Math.random() > 0.7 ? 
          (Math.random() > 0.5 ? 'up' : 'down') : 
          pattern.trend
      }))
    }));
  }, []);

  // Efeito para análise contínua
  useEffect(() => {
    if (!isAnalyzing) return;

    const predictionInterval = setInterval(generatePrediction, 30000); // Nova predição a cada 30s
    const patternInterval = setInterval(updatePatterns, 15000); // Atualizar padrões a cada 15s

    // Gerar primeira predição imediatamente
    generatePrediction();

    return () => {
      clearInterval(predictionInterval);
      clearInterval(patternInterval);
    };
  }, [isAnalyzing, generatePrediction, updatePatterns]);

  const toggleAnalysis = useCallback(() => {
    setIsAnalyzing(prev => !prev);
  }, []);

  const resetAnalysis = useCallback(() => {
    setCurrentPrediction(null);
    setConfidence(0);
    setIsAnalyzing(false);
    setLastUpdate(null);
    setAnalysisData(prev => ({
      ...prev,
      history: [],
      statistics: {
        totalPredictions: 0,
        correctPredictions: 0,
        accuracy: 0,
        streak: 0
      }
    }));
  }, []);

  return {
    currentPrediction,
    confidence,
    isAnalyzing,
    analysisData,
    toggleAnalysis,
    resetAnalysis,
    lastUpdate
  };
};