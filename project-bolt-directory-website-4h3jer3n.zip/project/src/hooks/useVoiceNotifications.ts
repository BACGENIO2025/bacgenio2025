import { useState, useCallback, useEffect } from 'react';

interface VoiceSettings {
  voice: SpeechSynthesisVoice | null;
  rate: number;
  volume: number;
  pitch: number;
}

export const useVoiceNotifications = () => {
  const [isEnabled, setIsEnabled] = useState(false);
  const [currentSettings, setCurrentSettings] = useState<VoiceSettings>({
    voice: null,
    rate: 1,
    volume: 1,
    pitch: 1
  });
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);

  // Carregar vozes disponíveis
  useEffect(() => {
    const loadVoices = () => {
      const voices = speechSynthesis.getVoices();
      setAvailableVoices(voices);
      
      // Tentar selecionar uma voz em português por padrão
      const portugueseVoice = voices.find(voice => 
        voice.lang.includes('pt') || voice.lang.includes('br')
      );
      
      if (portugueseVoice && !currentSettings.voice) {
        setCurrentSettings(prev => ({
          ...prev,
          voice: portugueseVoice
        }));
      }
    };

    loadVoices();
    speechSynthesis.addEventListener('voiceschanged', loadVoices);

    return () => {
      speechSynthesis.removeEventListener('voiceschanged', loadVoices);
    };
  }, [currentSettings.voice]);

  const speak = useCallback((text: string) => {
    if (!isEnabled || !text) return;

    // Cancelar qualquer fala anterior
    speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    
    if (currentSettings.voice) {
      utterance.voice = currentSettings.voice;
    }
    
    utterance.rate = currentSettings.rate;
    utterance.volume = currentSettings.volume;
    utterance.pitch = currentSettings.pitch;

    // Configurações adicionais
    utterance.lang = currentSettings.voice?.lang || 'pt-BR';

    speechSynthesis.speak(utterance);
  }, [isEnabled, currentSettings]);

  const toggle = useCallback(() => {
    setIsEnabled(prev => {
      const newState = !prev;
      
      if (newState) {
        // Testar se a API está disponível
        if (!('speechSynthesis' in window)) {
          console.warn('Speech Synthesis não suportado neste navegador');
          return false;
        }
        
        // Falar mensagem de ativação
        setTimeout(() => {
          speak('Sistema de notificações por voz ativado');
        }, 100);
      } else {
        // Cancelar qualquer fala em andamento
        speechSynthesis.cancel();
      }
      
      return newState;
    });
  }, [speak]);

  const setVoice = useCallback((voice: SpeechSynthesisVoice | null) => {
    setCurrentSettings(prev => ({
      ...prev,
      voice
    }));
  }, []);

  const setRate = useCallback((rate: number) => {
    setCurrentSettings(prev => ({
      ...prev,
      rate: Math.max(0.1, Math.min(10, rate))
    }));
  }, []);

  const setVolume = useCallback((volume: number) => {
    setCurrentSettings(prev => ({
      ...prev,
      volume: Math.max(0, Math.min(1, volume))
    }));
  }, []);

  const setPitch = useCallback((pitch: number) => {
    setCurrentSettings(prev => ({
      ...prev,
      pitch: Math.max(0, Math.min(2, pitch))
    }));
  }, []);

  // Limpar ao desmontar
  useEffect(() => {
    return () => {
      speechSynthesis.cancel();
    };
  }, []);

  return {
    isEnabled,
    toggle,
    speak,
    setVoice,
    setRate,
    setVolume,
    setPitch,
    currentSettings,
    availableVoices
  };
};