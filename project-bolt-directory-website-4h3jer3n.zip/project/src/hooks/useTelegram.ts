import { useCallback } from 'react';

const TELEGRAM_TOKEN = '8147876704:AAE9WXFiyCTgmGWAfgbASc_dR6Pk7qSOpps';
const CHAT_ID = '1483291576';

export const useTelegram = () => {
  const sendTelegramMessage = useCallback(async (message: string) => {
    try {
      const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: CHAT_ID,
          text: message,
          parse_mode: 'HTML'
        })
      });

      if (!response.ok) {
        throw new Error('Erro ao enviar mensagem para o Telegram');
      }

      return await response.json();
    } catch (error) {
      console.error('Erro ao enviar mensagem para o Telegram:', error);
      throw error;
    }
  }, []);

  const sendFootballAlert = useCallback(async (
    strategy: string,
    homeTeam: string,
    awayTeam: string,
    time: number,
    details: string
  ) => {
    const message = `
🚨 <b>ALERTA FUTEBOL - GENIO API</b>

⚽ <b>Estratégia:</b> ${strategy}
🏟️ <b>Jogo:</b> ${homeTeam} x ${awayTeam}
⏰ <b>Tempo:</b> ${time}'
📊 <b>Detalhes:</b> ${details}

🔗 <a href="https://www.bet365.bet.br">Bet365</a>
🎯 <a href="https://go.aff.esportesdasorte.com/8fg8vj6l">Esportes da Sorte</a>

#GenioAPI #Futebol #Estrategia
    `;

    return sendTelegramMessage(message);
  }, [sendTelegramMessage]);

  const sendBacBoAlert = useCallback(async (
    prediction: string,
    confidence: number,
    mode: string
  ) => {
    const message = `
🤖 <b>GENIO API - PREDIÇÃO BAC BO</b>

🎯 <b>Predição:</b> ${prediction.toUpperCase()}
📊 <b>Confiança:</b> ${confidence.toFixed(1)}%
⚙️ <b>Modo:</b> ${mode.toUpperCase()}

🕐 <b>Horário:</b> ${new Date().toLocaleTimeString('pt-BR')}

#GenioAPI #BacBo #ML
    `;

    return sendTelegramMessage(message);
  }, [sendTelegramMessage]);

  return {
    sendTelegramMessage,
    sendFootballAlert,
    sendBacBoAlert
  };
};