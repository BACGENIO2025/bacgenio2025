import { useState, useCallback } from 'react';
import { BankManagement } from '../types';

export const useBankManagement = () => {
  const [bankData, setBankData] = useState<BankManagement>({
    initialBank: 100,
    currentBank: 100,
    target: 200,
    stopLoss: 50,
    stopWin: 300,
    entryValue: 5
  });

  const updateBank = useCallback((field: keyof BankManagement, value: number) => {
    setBankData(prev => ({
      ...prev,
      [field]: value
    }));
  }, []);

  const deposit = useCallback((amount: number) => {
    setBankData(prev => ({
      ...prev,
      currentBank: prev.currentBank + amount
    }));
  }, []);

  const withdraw = useCallback((amount: number) => {
    setBankData(prev => ({
      ...prev,
      currentBank: Math.max(0, prev.currentBank - amount)
    }));
  }, []);

  const resetBank = useCallback(() => {
    setBankData({
      initialBank: 100,
      currentBank: 100,
      target: 200,
      stopLoss: 50,
      stopWin: 300,
      entryValue: 5
    });
  }, []);

  const setPresetValues = useCallback((preset: 'conservative' | 'moderate' | 'aggressive') => {
    switch (preset) {
      case 'conservative':
        setBankData({
          initialBank: 100,
          currentBank: 100,
          target: 150,
          stopLoss: 80,
          stopWin: 200,
          entryValue: 5
        });
        break;
      case 'moderate':
        setBankData({
          initialBank: 500,
          currentBank: 500,
          target: 750,
          stopLoss: 350,
          stopWin: 1000,
          entryValue: 25
        });
        break;
      case 'aggressive':
        setBankData({
          initialBank: 1000,
          currentBank: 1000,
          target: 1500,
          stopLoss: 700,
          stopWin: 2000,
          entryValue: 50
        });
        break;
    }
  }, []);

  const getProgress = useCallback(() => {
    if (bankData.target <= bankData.initialBank) return 0;
    const progress = ((bankData.currentBank - bankData.initialBank) / (bankData.target - bankData.initialBank)) * 100;
    return Math.max(0, Math.min(100, progress));
  }, [bankData]);

  const getStatusColor = useCallback(() => {
    const profit = bankData.currentBank - bankData.initialBank;
    if (profit > 0) return 'text-green-400';
    if (profit < 0) return 'text-red-400';
    return 'text-white';
  }, [bankData]);

  const getRiskLevel = useCallback(() => {
    const currentRisk = (bankData.currentBank / bankData.initialBank) * 100;
    
    if (currentRisk >= 150) {
      return { level: 'Muito Alto', color: 'text-red-500' };
    } else if (currentRisk >= 120) {
      return { level: 'Alto', color: 'text-orange-500' };
    } else if (currentRisk >= 90) {
      return { level: 'Médio', color: 'text-yellow-500' };
    } else if (currentRisk >= 70) {
      return { level: 'Baixo', color: 'text-green-500' };
    } else {
      return { level: 'Crítico', color: 'text-red-600' };
    }
  }, [bankData]);

  return {
    bankData,
    updateBank,
    deposit,
    withdraw,
    resetBank,
    setPresetValues,
    getProgress,
    getStatusColor,
    getRiskLevel
  };
};