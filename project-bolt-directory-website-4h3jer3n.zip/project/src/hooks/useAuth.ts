import { useState, useEffect } from 'react';

interface User {
  id: string;
  email: string;
  displayName?: string;
}

export const useAuth = () => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simular carregamento inicial
    const savedUser = localStorage.getItem('genio-api-user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (error) {
        console.error('Erro ao carregar usuário:', error);
        localStorage.removeItem('genio-api-user');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    
    // Simular autenticação
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Verificar credenciais demo
    if (email === 'demo@genioapi.com' && password === '123456') {
      const userData: User = {
        id: '1',
        email: email,
        displayName: 'Usuário Demo'
      };
      
      setUser(userData);
      localStorage.setItem('genio-api-user', JSON.stringify(userData));
    } else {
      throw new Error('Credenciais inválidas');
    }
    
    setIsLoading(false);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('genio-api-user');
  };

  return {
    user,
    login,
    logout,
    isLoading
  };
};